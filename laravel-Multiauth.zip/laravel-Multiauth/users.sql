-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2022 at 06:40 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test2`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `is_admin`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'shamim', 'shamim.aiub2@gmail.com', NULL, '$2y$10$jrxch6Xa3Xj.vRW3TEOqx.Suc9TQwbNN.ZaDsfwYeuFnUmHfBI3fO', '', NULL, '2022-02-26 05:40:51', '2022-02-26 05:40:51'),
(2, 'rajib', 'shohan@gmail.com', 1, '$2y$10$qgYE5CwbfGuZEtHU8isY7uae0jF5fEKNaGAlBAVxyOu8gnZ4OoBRy', '', NULL, '2022-02-26 05:47:09', '2022-02-26 05:47:09'),
(3, 'shamim ahamed', 'shamim@gmail.com', NULL, '$2y$10$a0ZSDlzFZEE2m804DBGTuenuPPsO6X/63BhcjNUzEP3zqixr3J2Em', '', NULL, '2022-02-26 10:13:12', '2022-02-26 10:13:12'),
(4, 'sam', 'sam@gmail.com', NULL, '$2y$10$ksJDTVom4RjB/TDI18K/5uOeriMG84sQ.EFevV0FAH4.KbBOodgB2', 'active', NULL, '2022-02-26 10:20:18', '2022-02-26 10:20:18'),
(5, 'shamim ahamed', 'shamimah@gmail.com', NULL, '$2y$10$yfB54HKmx0cUFpFOagtW1./DF6h3rDRG5Co4ehuRDEoXhExHepjEu', 'active', NULL, '2022-02-26 10:36:36', '2022-02-26 10:36:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
